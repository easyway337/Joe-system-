// supabase-config.js — public Supabase project settings.
// Loaded as a plain <script> BEFORE auth.js on every page.
//
// SUPABASE_URL: same value as SUPABASE_URL in backend/.env
// SUPABASE_ANON_KEY: the "anon" / "public" key from
//   Supabase Dashboard -> Project Settings -> API
//   (⚠️ NOT the service_role key — that one must never appear in the browser)
//
// The anon key is DESIGNED to be public — Row Level Security on the actual
// data tables is what keeps it safe (see sql/auth_rls_lockdown.sql, which
// restricts every CRM/ERP table to the service_role only). The anon key
// here is only ever used to talk to Supabase's Auth endpoints.

window.SUPABASE_CONFIG = {
  SUPABASE_URL: "https://YOUR-PROJECT-REF.supabase.co",
  SUPABASE_ANON_KEY: "YOUR-ANON-PUBLIC-KEY",
};
